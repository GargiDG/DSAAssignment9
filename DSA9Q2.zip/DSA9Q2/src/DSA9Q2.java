
public class DSA9Q2 {

    public static void main(String[] args) {
        //int n = 3;
        int n = 5;
        int sum = calculateSum(n);
        System.out.println(sum);
    }

    public static int calculateSum(int n) {
        if (n == 1) {
            return 1;
        }
        return n + calculateSum(n - 1);
    }

}
