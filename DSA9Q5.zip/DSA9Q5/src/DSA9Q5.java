
public class DSA9Q5 {

	 public static void main(String[] args) {
	       // int[] arr = {1, 4, 3, -5, -4, 8, 6};
	        int[] arr = {1, 4, 45, 6, 10, -8};
	        int max = findMaximum(arr);
	        System.out.println(max);
	    }

	    public static int findMaximum(int[] arr) {
	        return findMaximumHelper(arr, 0, arr.length - 1);
	    }

	    private static int findMaximumHelper(int[] arr, int start, int end) {
	        if (start == end) {
	            return arr[start];
	        }

	        int mid = (start + end) / 2;
	        int leftMax = findMaximumHelper(arr, start, mid);
	        int rightMax = findMaximumHelper(arr, mid + 1, end);

	        return Math.max(leftMax, rightMax);
	    }
	}
	



