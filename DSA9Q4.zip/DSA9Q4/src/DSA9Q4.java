
public class DSA9Q4 {

	  public static void main(String[] args) {
	        int N = 2;
	        int P = 5;
	        		
	        int result = calculateExponent(N, P);
	        System.out.println(result);
	    }

	    public static int calculateExponent(int N, int P) {
	        if (P == 0) {
	            return 1;
	        }
	        return N * calculateExponent(N, P - 1);
	    }
}
