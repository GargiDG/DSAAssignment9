
public class DSA9Q3 {

    public static void main(String[] args) {
        int N = 5;
        //int N= 4;
        int factorial = calculateFactorial(N);
        System.out.println(factorial);
    }

    public static int calculateFactorial(int N) {
        if (N == 0 || N == 1) {
            return 1;
        }
        return N * calculateFactorial(N - 1);
    }

}
