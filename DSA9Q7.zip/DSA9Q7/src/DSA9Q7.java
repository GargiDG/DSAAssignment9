import java.util.*;
public class DSA9Q7 {

	
	    public static void main(String[] args) {
	        String S = "ABC";
	        List<String> permutations = findPermutations(S);
	        for (String permutation : permutations) {
	            System.out.println(permutation);
	        }
	    }

	    public static List<String> findPermutations(String S) {
	        List<String> permutations = new ArrayList<>();
	        generatePermutations("", S, permutations);
	        return permutations;
	    }

	    private static void generatePermutations(String prefix, String remaining, List<String> permutations) {
	        int length = remaining.length();
	        if (length == 0) {
	            permutations.add(prefix);
	        } else {
	            for (int i = 0; i < length; i++) {
	                char current = remaining.charAt(i);
	                String newPrefix = prefix + current;
	                String newRemaining = remaining.substring(0, i) + remaining.substring(i + 1);
	                generatePermutations(newPrefix, newRemaining, permutations);
	            }
	        }
	    }
	}
